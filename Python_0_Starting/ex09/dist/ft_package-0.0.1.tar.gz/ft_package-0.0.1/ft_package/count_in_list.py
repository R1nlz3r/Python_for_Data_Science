def count_in_list(lst: list, item: any) -> int:
    """ Count items in a list """
    return lst.count(item)
