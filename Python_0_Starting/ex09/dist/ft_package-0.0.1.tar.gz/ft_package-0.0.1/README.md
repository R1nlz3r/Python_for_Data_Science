# `ft_package.count_in_list`

**Function**: Count occurrences of an item in a list.

**Signature**:
```python
def count_in_list(lst: list, item: any) -> int

